# Machine Notes

## Connection
- Ethernet port on HMI or inside cabinet
- IP configured via Utility -> Network

## VNC Access
- Use UltraVNC Viewer
- IP: 192.168.0.1
- Password: x11vnc

## Known Registers
- 13300: format
- 10142: set format
- 10112: lot number
- 10161: package count

## Goal
Identify fault registers by comparing values during faults.
