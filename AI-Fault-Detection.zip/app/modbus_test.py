from pymodbus.client import ModbusTcpClient

client = ModbusTcpClient("192.168.0.1")
client.connect()

result = client.read_holding_registers(10000, 50)
print(result.registers)

client.close()
